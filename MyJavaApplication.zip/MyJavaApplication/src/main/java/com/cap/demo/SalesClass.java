package com.cap.demo;

public class SalesClass {
	
	private int[] datas={1,90,45,-34};
	
	public void display(){
		System.out.println("Sales Class Display Method");
	}

}
