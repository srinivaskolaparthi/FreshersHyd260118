package org.cap.exception;

public class AccountNotFound extends Exception {

	public AccountNotFound(String msg) {
		super(msg);
	}
}
